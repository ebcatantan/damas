<?php namespace App\Database\Migrations;

class AddIndicatorsBsmeAreaFour extends \CodeIgniter\Database\Migration {

        private $table = 'parameter_items';
        public function up()
        {
          $data = [
              [
                  'id' => ,
                  'parameter_item' => 'S.1. The institution has a system of determining its Vision and Mission.',
                  'description' => 'S.1. The institution has a system of determining its Vision and Mission.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '303', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
          ];
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $builder->insertBatch($data);
        }

        public function down()
        {
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $db->simpleQuery('DELETE FROM '.$this->table.' WHERE id >= 39 AND id <= 47');
        }
}
