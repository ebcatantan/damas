<?php namespace App\Database\Migrations;

class AddIndicatorsBsmeAreaSeven extends \CodeIgniter\Database\Migration {

        private $table = 'parameter_items';
        public function up()
        {
          $data = [
              [
                  'id' => 2000,
                  'parameter_item' => 'S.1. The organizatoinal structure of the library is well-defined.',
                  'description' => 'S.1. The organizatoinal structure of the library is well-defined.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2001,
                  'parameter_item' => 'S.2. The development of the library goals and objectives is the respnsibility of the library head and staff with the approval of the head of institution.',
                  'description' => 'S.2. The development of the library goals and objectives is the respnsibility of the library head and staff with the approval of the head of institution.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2002,
                  'parameter_item' => 'S.3. There is a library board/committee which sets library policies, rules and procedures and periodically review them.',
                  'description' => 'S.3. There is a library board/committee which sets library policies, rules and procedures and periodically review them.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2003,
                  'parameter_item' => 'S.4. There is a duly approved and widely discriminated library manual or written policies and procedures covering the librarys internal administration and operation.',
                  'description' => 'S.4. There is a duly approved and widely discriminated library manual or written policies and procedures covering the librarys internal administration and operation.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2004,
                  'parameter_item' => 'I.1. The library Develops an explicit statement of its goals and objectives in conformity with the mandate of the institution.',
                  'description' => 'I.1. The library Develops an explicit statement of its goals and objectives in conformity with the mandate of the institution.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2005,
                  'parameter_item' => 'I.2. The library is administered and supervised by:',
                  'description' => 'I.2. The library is administered and supervised by:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2006,
                  'parameter_item' => 'I.2.1. a full-time professional licensed librarian; and',
                  'description' => 'I.2.1. a full-time professional licensed librarian; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2007,
                  'parameter_item' => 'I.2.2. at least a masters degree holder in MS library and Information Science or MAEd/MA in library science.',
                  'description' => 'I.2.2. at least a masters degree holder in MS library and Information Science or MAEd/MA in library science.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2008,
                  'parameter_item' => 'I.3. The head librarian directs and supervises the total oparation of the library and is responsible for the administration of its resources and services.',
                  'description' => 'I.3. The head librarian directs and supervises the total oparation of the library and is responsible for the administration of its resources and services.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2009,
                  'parameter_item' => 'I.4. The head librarian, preferably with an academic rank, actively participates in the academic and administrative activities of the institution.',
                  'description' => 'I.4. The head librarian, preferably with an academic rank, actively participates in the academic and administrative activities of the institution.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2009,
                  'parameter_item' => 'I.5. The annual accomplishments and other reports of the library are promptly submitted to the higher offices concerned.',
                  'description' => 'I.5. The annual accomplishments and other reports of the library are promptly submitted to the higher offices concerned.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2010,
                  'parameter_item' => 'I.6. A library development plan is prepared in consultation with the institutions officials and stakeholders.',
                  'description' => 'I.6. A library development plan is prepared in consultation with the institutions officials and stakeholders.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2011,
                  'parameter_item' => 'O.1. The goals and obejectives of the library are satisfactorily attained.',
                  'description' => 'O.1. The goals and obejectives of the library are satisfactorily attained.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2012,
                  'parameter_item' => 'O.2. The library organiztional structure is well-designed and effectively implemented.',
                  'description' => 'O.2. The library organiztional structure is well-designed and effectively implemented.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '28', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2013,
                  'parameter_item' => 'S.1. The library has staff with the following qualifications:',
                  'description' => 'S.1. The library has staff with the following qualifications:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2014,
                  'parameter_item' => 'S.1.1. BS in library and Information science for the college/academic unit library; and',
                  'description' => 'S.1.1. BS in library and Information science for the college/academic unit library; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2015,
                  'parameter_item' => 'S.1.2. MS in library and Information Science or MAED/MA in library) for the institution.',
                  'description' => 'S.1.2. MS in library and Information Science or MAED/MA in library) for the institution.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2016,
                  'parameter_item' => 'S.2. The library meets the required number of qualified and licensed librarians and staff to meet the needs of the school population with the ratio of:',
                  'description' => 'S.2. The library meets the required number of qualified and licensed librarians and staff to meet the needs of the school population with the ratio of:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2017,
                  'parameter_item' => 'S.2.1. one (1) licensed librarian with two (2) full time staff for the first 500-student population ; and',
                  'description' => 'S.2.1. one (1) licensed librarian with two (2) full time staff for the first 500-student population ; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2018,
                  'parameter_item' => 'S.2.2. one (1) additional full time professional librarian with one (1) full time staff for every',
                  'description' => 'S.2.2. one (1) additional full time professional librarian with one (1) full time staff for every',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2019,
                  'parameter_item' => 'S.3. There is a continuing staff development program with the corresponding Financial assistance from the institution.',
                  'description' => 'S.3. There is a continuing staff development program with the corresponding Financial assistance from the institution.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2020,
                  'parameter_item' => 'I.1. The library staff compensation, retirement, and fringe benefits, as well as other privilages, are granted in accordance with existing goverment laws and institutional policies.',
                  'description' => 'I.1. The library staff compensation, retirement, and fringe benefits, as well as other privilages, are granted in accordance with existing goverment laws and institutional policies.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2021,
                  'parameter_item' => 'O.1. The librarians are qualified',
                  'description' => 'O.1. The librarians are qualified',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '29', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2022,
                  'parameter_item' => 'S.1. There is a written colllection development policy.',
                  'description' => 'S.1. There is a written colllection development policy.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2023,
                  'parameter_item' => 'S.2. There is a core collection of ar least:',
                  'description' => 'S.2. There is a core collection of ar least:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2024,
                  'parameter_item' => 'S.2.1. 5000 titles for the academic unit library; or',
                  'description' => 'S.2.1. 5000 titles for the academic unit library; or',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2025,
                  'parameter_item' => 'S.2.2. 10,000 titles that suppport the instruction. research and other programs for an intitution library.',
                  'description' => 'S.2.2. 10,000 titles that suppport the instruction. research and other programs for an intitution library.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              [
                  'id' => 2026,
                  'parameter_item' => 'S.3. Twenty Percent(20%) of the library holdings are of current edition, i.e. with copyright within the last five years.',
                  'description' => 'S.3. Twenty Percent(20%) of the library holdings are of current edition, i.e. with copyright within the last five years.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2027,
                  'parameter_item' => 'S.4. The non-print, digital and electronic resources are available.',
                  'description' => 'S.4. The non-print, digital and electronic resources are available.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2028,
                  'parameter_item' => 'S.5. There is an integrated library system.',
                  'description' => 'S.5. There is an integrated library system.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2029,
                  'parameter_item' => 'S.6. There are provisions for the preservation, general care, and unkeep of library resources.',
                  'description' => 'S.6. There are provisions for the preservation, general care, and unkeep of library resources.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2030,
                  'parameter_item' => 'I.1. The Collection  Development Policy is regularly reviewed and evaluated by the library committee.',
                  'description' => 'I.1. The Collection  Development Policy is regularly reviewed and evaluated by the library committee.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2031,
                  'parameter_item' => 'I.2. The library collection and services support the mission vision of the institution, goals of the college/academic unit and obejectives of the program.',
                  'description' => 'I.2. The library collection and services support the mission vision of the institution, goals of the college/academic unit and obejectives of the program.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2032,
                  'parameter_item' => 'I.3. The library provides sufficient research books and materials to supplement the clients curricular needs.',
                  'description' => 'I.3. The library provides sufficient research books and materials to supplement the clients curricular needs.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2033,
                  'parameter_item' => 'I.4. The library maintains and extensive (15% of the total) Filipiniana collection',
                  'description' => 'I.4. The library maintains and extensive (15% of the total) Filipiniana collection',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2034,
                  'parameter_item' => 'I.5. The library provides 3-5 book/journal titles for professional subjects in the major fields of specialization.',
                  'description' => 'I.5. The library provides 3-5 book/journal titles for professional subjects in the major fields of specialization.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2035,
                  'parameter_item' => 'I.6. The library collection is organized according to an accepted scheme of classification and standard code of cataloguing.',
                  'description' => 'I.6. The library collection is organized according to an accepted scheme of classification and standard code of cataloguing.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2035,
                  'parameter_item' => 'I.7. Regular weeding-out program is conducted to maintain a relevant and updated collection',
                  'description' => 'I.7. Regular weeding-out program is conducted to maintain a relevant and updated collection',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2036,
                  'parameter_item' => 'I.8. The quality and quantity of library materials and resources conform with the standard set for a particular academic program.',
                  'description' => 'I.8. The quality and quantity of library materials and resources conform with the standard set for a particular academic program.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2037,
                  'parameter_item' => 'O.1. The library core collection is adequate, updated and well-balanced.',
                  'description' => 'O.1. The library core collection is adequate, updated and well-balanced.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2038,
                  'parameter_item' => 'O.2. The professional books, journals and electronic resources for the program are sufficient.',
                  'description' => 'O.2. The professional books, journals and electronic resources for the program are sufficient.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '30', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2039,
                  'parameter_item' => 'S.1. The library has information services pertinent to the institutions requirements.',
                  'description' => 'S.1. The library has information services pertinent to the institutions requirements.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2040,
                  'parameter_item' => 'I.1. The following sservices/programs are provided:',
                  'description' => 'I.1. The following sservices/programs are provided:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2041,
                  'parameter_item' => 'I.1.1. functional and interactive library web page;',
                  'description' => 'I.1.1. functional and interactive library web page;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2042,
                  'parameter_item' => 'I.1.2. integrated library system;',
                  'description' => 'I.1.2. integrated library system;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2043,
                  'parameter_item' => 'I.1.3. on-line public access(OPAC)',
                  'description' => 'I.1.3. on-line public access(OPAC)',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2044,
                  'parameter_item' => 'I.1.4. circulation on-line;',
                  'description' => 'I.1.4. circulation on-line;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2045,
                  'parameter_item' => 'I.1.5. computerized cataloguing;',
                  'description' => 'I.1.5. computerized cataloguing;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2046,
                  'parameter_item' => 'I.1.6. inventory reporting;',
                  'description' => 'I.1.6. inventory reporting;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2047,
                  'parameter_item' => 'I.1.7. serials control;',
                  'description' => 'I.1.7. serials control;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2048,
                  'parameter_item' => 'I.1.8. internet searching;',
                  'description' => 'I.1.8. internet searching;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2049,
                  'parameter_item' => 'I.1.9. CD-ROM;',
                  'description' => 'I.1.9. CD-ROM;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2050,
                  'parameter_item' => 'I.1.10. on-line database;',
                  'description' => 'I.1.10. on-line database;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2051,
                  'parameter_item' => 'I.1.11. photocopying; and;',
                  'description' => 'I.1.11. photocopying; and;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2052,
                  'parameter_item' => 'I.1.12. bar coding.',
                  'description' => 'I.1.12. bar coding.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2053,
                  'parameter_item' => 'I.2. The library opens at least 54 hours a week for the college/academic unit or 60 hours per week for institution.',
                  'description' => 'I.2 The library opens at least 54 hours a week for the college/academic unit or 60 hours per week for institution.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2054,
                  'parameter_item' => 'I.3. The library promotes and disseminates its program through a regular announcement its new acquisition of print material (books, journal, magazines) resources, facilities, and services.',
                  'description' => 'I.3. The library promotes and disseminates its program through a regular announcement its new acquisition of print material (books, journal, magazines) resources, facilities, and services.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2055,
                  'parameter_item' => 'I.4. Librarians and staff are available during library hours to assist and provide library services.',
                  'description' => 'I.4. Librarians and staff are available during library hours to assist and provide library services.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2056,
                  'parameter_item' => 'I.5. Statistical data on the utilization of various resources and services are compiled and used to improve the library collection and operations.',
                  'description' => 'I.5. Statistical data on the utilization of various resources and services are compiled and used to improve the library collection and operations.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2057,
                  'parameter_item' => 'O.1. The library sevices are efficiently and effectively provided.',
                  'description' => 'O.1. The library sevices are efficiently and effectively provided.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2058,
                  'parameter_item' => 'O.2. The library users are satisfied with library services.',
                  'description' => 'O.2. The library users are satisfied with library services.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '31', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2059,
                  'parameter_item' => 'S.1. The library is strategically located and accessible to students, faculty and other clientele.',
                  'description' => 'S.1. The library is strategically located and accessible to students, faculty and other clientele.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2060,
                  'parameter_item' => 'S.2. The library is systematically planned to allow future expansions.',
                  'description' => 'S.2. The library is systematically planned to allow future expansions.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2061,
                  'parameter_item' => 'S.3. The size of the library meets standard requirements considering the present enrolment and future expansion.',
                  'description' => 'S.3. The size of the library meets standard requirements considering the present enrolment and future expansion.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2062,
                  'parameter_item' => 'S.4. The reading room can accomodate at least 10% of the school enrolment at any given time.',
                  'description' => 'S.4. The reading room can accomodate at least 10% of the school enrolment at any given time.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2063,
                  'parameter_item' => 'S.5. Space is provided for print resources as well as work stations for electronic resources.',
                  'description' => 'S.5. Space is provided for print resources as well as work stations for electronic resources.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2064,
                  'parameter_item' => 'S.6. Space is provided for the librarians office, staff room, technical room, etc.',
                  'description' => 'S.6. Space is provided for the librarians office, staff room, technical room, etc.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2065,
                  'parameter_item' => 'S.7. Ramps for the physically disabled are provided',
                  'description' => 'S.7. Ramps for the physically disabled are provided',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2066,
                  'parameter_item' => 'S.8. The library meets the required and standard-sized furniture and equipment.',
                  'description' => 'S.8. The library meets the required and standard-sized furniture and equipment.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2067,
                  'parameter_item' => 'S.9. The following library furniture and equipment are available:',
                  'description' => 'S.9. The following library furniture and equipment are available:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2068,
                  'parameter_item' => 'S.9.1. adjustable/movable shelves;',
                  'description' => 'S.9.1. adjustable/movable shelves;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2068,
                  'parameter_item' => 'S.9.2. magazine display shelves;',
                  'description' => 'S.9.2. magazine display shelves;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2069,
                  'parameter_item' => 'S.9.3. newspaper ranks;',
                  'description' => 'S.9.3. newspaper ranks;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2070,
                  'parameter_item' => 'S.9.4. standard tables and chair;',
                  'description' => 'S.9.4. standard tables and chair;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2071,
                  'parameter_item' => 'S.9.5. carrels for individual study;',
                  'description' => 'S.9.5. carrels for individual study;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2072,
                  'parameter_item' => 'S.9.6. desks and chair for staff;',
                  'description' => 'S.9.6. desks and chair for staff;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2073,
                  'parameter_item' => 'S.9.7. charging desk;',
                  'description' => 'S.9.7. charging desk;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2074,
                  'parameter_item' => 'S.9.8. dictionary stand;',
                  'description' => 'S.9.8. dictionary stand;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2075,
                  'parameter_item' => 'S.9.9. atlas stand;',
                  'description' => 'S.9.9. atlas stand;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2076,
                  'parameter_item' => 'S.9.11. vertical file cabinets;',
                  'description' => 'S.9.11. vertical file cabinets;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              [
                  'id' => 2077,
                  'parameter_item' => 'S.9.12. book racks;',
                  'description' => 'S.9.12. book racks;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2078,
                  'parameter_item' => 'S.9.13. map stands/cabinets',
                  'description' => 'S.9.13. map stands/cabinets',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2079,
                  'parameter_item' => 'S.9.14. cardex/rotadex or any filing equipment for periodical records;',
                  'description' => 'S.9.14. cardex/rotadex or any filing equipment for periodical records;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2080,
                  'parameter_item' => 'S.9.15. typewrites;',
                  'description' => 'S.9.15. typewrites;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2081,
                  'parameter_item' => 'S.9.16. computers with printers;',
                  'description' => 'S.9.16. computers with printers;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2081,
                  'parameter_item' => 'S.9.17. others(please specify)',
                  'description' => 'S.9.17. others(please specify)',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2082,
                  'parameter_item' => 'S.10. The library is well lighted.',
                  'description' => 'S.10. The library is well lighted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2083,
                  'parameter_item' => 'S.11. The library is well ventilated.',
                  'description' => 'S.11. The library is well ventilated.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2084,
                  'parameter_item' => 'S.12. The atmosphere is conductive to learning.',
                  'description' => 'S.12. The atmosphere is conductive to learning.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2085,
                  'parameter_item' => 'S.13. Fire extinguisherand a local fire alarm system are available.',
                  'description' => 'S.13. Fire extinguisherand a local fire alarm system are available.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2086,
                  'parameter_item' => 'S.14. The library employs a systtem for security and control of library resources.',
                  'description' => 'S.14. The library employs a systtem for security and control of library resources.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2087,
                  'parameter_item' => 'I.1. IT software and multi-media equipment are utilized.',
                  'description' => 'I.1. IT software and multi-media equipment are utilized.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2088,
                  'parameter_item' => 'O.1. The environment in the library is conductive to learning.',
                  'description' => 'O.1. The environment in the library is conductive to learning.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2089,
                  'parameter_item' => 'O.2. The library facilities are well-maintained and aesthetically designed.',
                  'description' => 'O.2. The library facilities are well-maintained and aesthetically designed.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2090,
                  'parameter_item' => 'I.1. The head librarian and staff, in coordination with other officials of the institution, prepare and manage the annual library budget.',
                  'description' => 'I.1. The head librarian and staff, in coordination with other officials of the institution, prepare and manage the annual library budget.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2091,
                  'parameter_item' => 'I.2. All fess and funds allocated for library resources and services are utilized solely for sudh purposes and are properly audited.',
                  'description' => 'I.2. All fess and funds allocated for library resources and services are utilized solely for sudh purposes and are properly audited.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2092,
                  'parameter_item' => 'I.3. Other sources of financial assistance are sought.',
                  'description' => 'I.3. Other sources of financial assistance are sought.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2093,
                  'parameter_item' => 'O.1. The financial support from fiduciary, supplemental and external funds is adequate.',
                  'description' => 'O.1. The financial support from fiduciary, supplemental and external funds is adequate.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '32', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2094,
                  'parameter_item' => 'S.1. The library is on the mailing lisf of agencies, foundations, etc., for exchange of publications and other books and jounals donations.',
                  'description' => 'S.1. The library is on the mailing lisf of agencies, foundations, etc., for exchange of publications and other books and jounals donations.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '34', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2095,
                  'parameter_item' => 'I.1. Linkages with other institutions and funding agencies are explored and established for purposes of echancing library facilities and resources.',
                  'description' => 'I.1. Linkages with other institutions and funding agencies are explored and established for purposes of echancing library facilities and resources.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '34', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2096,
                  'parameter_item' => 'I.2.The library establishes consortia, networking and resource sharing with other institutions and library collaborative activities.',
                  'description' => 'I.2. The library establishes consortia, networking and resource sharing with other institutions and library collaborative activities.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '34', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2097,
                  'parameter_item' => 'O.1. Library resource sharing and linkages are well-established.',
                  'description' => 'O.1. Library resource sharing and linkages are well-established.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '306', //accre template course area
                  'template_parameter_id' => '34', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],

          ];
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $builder->insertBatch($data);
        }

        public function down()
        {
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $db->simpleQuery('DELETE FROM '.$this->table.' WHERE id >= 39 AND id <= 47');
        }
}
