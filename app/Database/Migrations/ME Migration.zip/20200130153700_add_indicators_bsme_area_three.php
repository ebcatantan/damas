<?php namespace App\Database\Migrations;

class AddIndicatorsBsmeAreaThree extends \CodeIgniter\Database\Migration {

        private $table = 'parameter_items';
        public function up()
        {
          $data = [
              [
                  'id' => 1800,
                  'parameter_item' => 'S.1. The curriculum provides for the development of the following professional competencies: ',
                  'description' => 'S.1. The curriculum provides for the development of the following professional competencies: ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1697,
                  'parameter_item' => 'S.1.1. acquisition of knowledge and theories based on the field of specialization/discipline; ',
                  'description' => 'S.1.1. acquisition of knowledge and theories based on the field of specialization/discipline; ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1698,
                  'parameter_item' => 'S.1.2. application of the theories to real problems in the field; and ',
                  'description' => 'S.1.2. application of the theories to real problems in the field; and ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1699,
                  'parameter_item' => 'S.1.3. demonstration of skills in applying different strategies in the actual work setting. ',
                  'description' => 'S.1.3. demonstration of skills in applying different strategies in the actual work setting. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1700,
                  'parameter_item' => 'S.2. There is a system of validation of subjects taken from other schools. ',
                  'description' => 'S.2. There is a system of validation of subjects taken from other schools. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1701,
                  'parameter_item' => 'S.3. The curriculum reflects local, regional and national development goals as well as the institution’s vision and mission. ',
                  'description' => 'S.3. The curriculum reflects local, regional and national development goals as well as the institution’s vision and mission. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1702,
                  'parameter_item' => 'I.1. The curriculum/ program of study meets the requirements and standards of CHED, and the total number of units of the curriculum is equivalent to or judiciously exceeds the CHED prescribed units in consonance of CMO No.9 s 2008 as follows: ',
                  'description' => 'I.1. The curriculum/ program of study meets the requirements and standards of CHED, and the total number of units of the curriculum is equivalent to or judiciously exceeds the CHED prescribed units in consonance of CMO No.9 s 2008 as follows: ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1703,
                  'parameter_item' => 'I.1.1. Technical Courses  -  158 units (Mathematics: 26 Units, Natural/Physical Sciences: 12 Units, Allied Courses: 10 Units, Professional Courses: 23 Units, Technical Electives: 12 UNits, Fundamental Courses: 54 Units, On-the-job Training)',
                  'description' => 'I.1.1. Technical Courses  -  158 units (Mathematics: 26 Units, Natural/Physical Sciences: 12 Units, Allied Courses: 10 Units, Professional Courses: 23 Units, Technical Electives: 12 UNits, Fundamental Courses: 54 Units, On-the-job Training)',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1704,
                  'parameter_item' => 'I.1.2. Non-Technical Course  -  53 units (Social Sciences: 12Units, Humanities: 9 Units, Languages; 15 Units, Life and Works of Rizal: 3 Units, Physical Education: 8 Units, National Service Training Program: 6 Units)',
                  'description' => 'I.1.2. Non-Technical Course  -  53 units (Social Sciences: 12Units, Humanities: 9 Units, Languages; 15 Units, Life and Works of Rizal: 3 Units, Physical Education: 8 Units, National Service Training Program: 6 Units)',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1705,
                  'parameter_item' => 'I.2. The subjects are logically sequenced and prerequisite courses are identified. ',
                  'description' => 'I.2. The subjects are logically sequenced and prerequisite courses are identified. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1706,
                  'parameter_item' => 'I.3. The curricular content is responsive to the needs of the country and recent developments in the profession. ',
                  'description' => 'I.3. The curricular content is responsive to the needs of the country and recent developments in the profession. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1707,
                  'parameter_item' => 'I.4. The curricular content covers the extent of the professional and technical preparation required of its graduates such as; ',
                  'description' => 'I.4. The curricular content covers the extent of the professional and technical preparation required of its graduates such as; ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1708,
                  'parameter_item' => 'I.4.1. alternative sources of energy/renewable energy; ',
                  'description' => 'I.4.1. alternative sources of energy/renewable energy; ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1709,
                  'parameter_item' => 'I.4.2. mechatronics/robotics/nanotechnology;',
                  'description' => 'I.4.2. mechatronics/robotics/nanotechnology;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1710,
                  'parameter_item' => 'I.4.3. manufacturing technologies;',
                  'description' => 'I.4.3. manufacturing technologies;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1711,
                  'parameter_item' => 'I.4.4. thermofluid science;',
                  'description' => 'I.4.4. thermofluid science;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1712,
                  'parameter_item' => 'I.4.5. biomedical science; and',
                  'description' => 'I.4.5. biomedical science; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1713,
                  'parameter_item' => 'I.4.6. environmental technology. ',
                  'description' => 'I.4.6. environmental technology. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1714,
                  'parameter_item' => 'I.5. The curriculum integrates values, reflective of national customs, culture and tradition in cases where applicable. ',
                  'description' => 'I.5. The curriculum integrates values, reflective of national customs, culture and tradition in cases where applicable. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1715,
                  'parameter_item' => 'I.6. Opportunities for participation in hands-on activities such as immersion/practical training and field study are maintained in the curriculum. ',
                  'description' => 'I.6. Opportunities for participation in hands-on activities such as immersion/practical training and field study are maintained in the curriculum. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1716,
                  'parameter_item' => 'I.7. The following activities are undertaken to ensure quality in the process of curriculum development: ',
                  'description' => 'I.7. The following activities are undertaken to ensure quality in the process of curriculum development: ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1718,
                  'parameter_item' => 'I.7.1 participative planning and designing of the curriculum by the following stakeholders: ',
                  'description' => 'I.7.1 participative planning and designing of the curriculum by the following stakeholders: ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1719,
                  'parameter_item' => 'I.7.1.1. administration; ',
                  'description' => 'I.7.1.1. administration; ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1720,
                  'parameter_item' => 'I.7.1.2. faculty;',
                  'description' => 'I.7.1.2. faculty; ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1721,
                  'parameter_item' => 'I.7.1.3. students; ',
                  'description' => 'I.7.1.3. students; ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1721,
                  'parameter_item' => 'I.7.1.4. alumni; ',
                  'description' => 'I.7.1.4. alumni; ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1722,
                  'parameter_item' => 'I.7.1.5. representatives from the industry and;',
                  'description' => 'I.7.1.5. representatives from the industry and;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1723,
                  'parameter_item' => 'I.7.1.6. others (please specify) ',
                  'description' => 'I.7.1.6. others (please specify) ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1724,
                  'parameter_item' => 'I.7.2 periodic review, assessment, updating and approval of the curriculum by the Academic Council; and ',
                  'description' => 'I.7.2 periodic review, assessment, updating and approval of the curriculum by the Academic Council; and ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1725,
                  'parameter_item' => 'I.7.3 confirmation of the curriculum by the Board of Regents/Trustees (BOR/BOT)',
                  'description' => 'I.7.3 confirmation of the curriculum by the Board of Regents/Trustees (BOR/BOT)',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1726,
                  'parameter_item' => 'I.7.4 others (please specify) ',
                  'description' => 'I.7.4 others (please specify) ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1727,
                  'parameter_item' => 'I.8. The program of study allows the accommodation of students with special needs and assists them to finish the degree. ',
                  'description' => 'I.8. The program of study allows the accommodation of students with special needs and assists them to finish the degree. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1728,
                  'parameter_item' => 'O.1. The curriculum is responsive and relevant to the demands of the times.',
                  'description' => 'O.1. The curriculum is responsive and relevant to the demands of the times',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 1729,
                  'parameter_item' => 'O.2. There is a passing average performance in the Licensure Examination for Mechanical Engineering ',
                  'description' => 'O.2. There is a passing average performance in the Licensure Examination for Mechanical Engineering ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              //Paramenter b
              [
                  'id' => 1729,
                  'parameter_item' => 'O.2. There is a passing average performance in the Licensure Examination for Mechanical Engineering ',
                  'description' => 'O.2. There is a passing average performance in the Licensure Examination for Mechanical Engineering ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '302', //accre template course area
                  'template_parameter_id' => '11', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],

          ];
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $builder->insertBatch($data);
        }

        public function down()
        {
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $db->simpleQuery('DELETE FROM '.$this->table.' WHERE id >= 39 AND id <= 47');
        }
}
