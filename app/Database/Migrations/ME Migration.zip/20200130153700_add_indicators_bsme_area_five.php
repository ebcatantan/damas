<?php namespace App\Database\Migrations;

class AddIndicatorsBsmeAreaOne extends \CodeIgniter\Database\Migration {

        private $table = 'parameter_items';
        public function up()
        {
          $data = [
              [
                  'id' => 4000,
                  'parameter_item' => 'S.1. The institutions research agend is in consonance with institutional, regional and national priorities concerned such as DOST, CHED-National Higher Education Research Agenda, NDEA,ect.',
                  'description' => 'S.1. The institutions research agend is in consonance with institutional, regional and national priorities concerned such as DOST, CHED-National Higher Education Research Agenda, NDEA,ect.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4001,
                  'parameter_item' => 'S.2. The institution has an approved Research Manual ',
                  'description' => 'S.2. The institution has an approved Research Manual.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4002,
                  'parameter_item' => 'I.1. The approved Research Agenda is implemented.',
                  'description' => 'I.1. The approved Research Agenda is implemented.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4003,
                  'parameter_item' => 'I.2. The following stakeholders participate in the formulation of research agenda as bases for identifying institutional thrusts and priorities ',
                  'description' => 'I.2. The following stakeholders participate in the formulation of research agenda as bases for identifying institutional thrusts and priorities ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4004,
                  'parameter_item' => 'I.2.1. administrators;',
                  'description' => 'I.2.1. faculty;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '4003', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4005,
                  'parameter_item' => 'I.2.2. faculty;',
                  'description' => 'I.2.2. faculty;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '4003', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4006,
                  'parameter_item' => 'I.2.3. students;',
                  'description' => 'I.2.3. students;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '4003', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4007,
                  'parameter_item' => 'I.2.4. government agency representatives (DOST,CHED,NEDA,etc.);and',
                  'description' => 'I.2.4. government agency representatives (DOST,CHED,NEDA,etc.);and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '4003', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4008,
                  'parameter_item' => 'I.2.5. other stakeholders(alumni,parents,etc).',
                  'description' => 'I.2.5. other stakeholders(alumni,parents,etc).',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '4003', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4009,
                  'parameter_item' => 'I.3. Active researches to test theory in practice are conducted by faculty and students.',
                  'description' => 'I.3. Active researches to test theory in practice are conducted by faculty and students.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4010,
                  'parameter_item' => 'I.4. Team/collaborative and interdisciplinary research is encouraged.',
                  'description' => 'I.4. Team/collaborative and interdisciplinary research is encouraged.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4011,
                  'parameter_item' => 'I.5. Research outputs are published referred national and/or international journals',
                  'description' => 'I.5. Research outputs are published referred national and/or international journals',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4012,
                  'parameter_item' => 'O.1. Priority researches are identified and conducted.',
                  'description' => 'O.1. Priority researches are identified and conducted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4013,
                  'parameter_item' => 'O.2. Research results are published.',
                  'description' => 'O.2. Research results are published.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4014,
                  'parameter_item' => 'S.1. The institution has an approved and adequate budget for research. ',
                  'description' => 'S.1. The institution has an approved and adequate budget for research. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4015,
                  'parameter_item' => 'S.2. There are provisions for the following: '
                  'description' => 'S.2. There are provisions for the following: '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4016,
                  'parameter_item' => 'S.2.1. facilities and equipment such as internet, statistical software, and other ICT resources,'
                  'description' => 'S.2.1. facilities and equipment such as internet, statistical software, and other ICT resources,'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4015', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4017,
                  'parameter_item' => 'S.2.2. research staff'
                  'description' => 'S.2.2. research staff'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4015', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4018,
                  'parameter_item' => 'S.2.3. suppliers and materials; and'
                  'description' => 'S.2.3. suppliers and materials; and'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4015', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4019,
                  'parameter_item' => 'S.2.4. workplace'
                  'description' => 'S.2.4. workplace'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4015', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4020,
                  'parameter_item' => 'I.1. allocates adequate funds for the conduct of faculty and students research'
                  'description' => 'I.1. allocates adequate funds for the conduct of faculty and students research'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4021,
                  'parameter_item' => 'I.2. establishes linkages with the local/national/international agencies for funding support and assistance.'
                  'description' => 'I.2. establishes linkages with the local/national/international agencies for funding support and assistance.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4022,
                  'parameter_item' => 'I.3. maintains a functional and long-range program of faculty/staff development to enchance research capability and competence.'
                  'description' => 'I.3. maintains a functional and long-range program of faculty/staff development to enchance research capability and competence.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4023,
                  'parameter_item' => 'I.4. encourages the conduct of externally funded researches.'
                  'description' => 'I.4. encourages the conduct of externally funded researches.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4024,
                  'parameter_item' => 'O.1. Research Program is adequately funded.'
                  'description' => 'O.1. Research Program is adequately funded.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4025,
                  'parameter_item' => 'S.1. There is a system of implementations, monitoring, evaluation and utilization of research outputs.'
                  'description' => 'S.1. There is a system of implementations, monitoring, evaluation and utilization of research outputs.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4026,
                  'parameter_item' => 'S.2. The institution has a policy on Intellectual Property Rights(IPR)'
                  'description' => 'S.2. The institution has a policy on Intellectual Property Rights(IPR)'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4027,
                  'parameter_item' => 'I.1. The institution/College/Academic Unit has a Research Unit managed by competent staff'
                  'description' => 'I.1. The institution/College/Academic Unit has a Research Unit managed by competent staff'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4028,
                  'parameter_item' => 'I.2. The Research Manual provides guidellines and procedures for the administration and conduct of research.'
                  'description' => 'I.2. The Research Manual provides guidellines and procedures for the administration and conduct of research.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4029,
                  'parameter_item' => 'I.3. The faculty conduct applied and operational researches in their fields of specilization in accordance with the thrusts and priorities of the program/institution'
                  'description' => 'I.3. The faculty conduct applied and operational researches in their fields of specilization in accordance with the thrusts and priorities of the program/institution'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4030,
                  'parameter_item' => 'I.4. The institution provides incentives to faculty reseachers such as honoraria, service credits, deloading, etc.'
                  'description' => 'I.4. The institution provides incentives to faculty reseachers such as honoraria, service credits, deloading, etc.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4031,
                  'parameter_item' => 'I.5. The College/Academic Unit requires its students to conduct research, as a course requirement, (whenever applicable.)'
                  'description' => 'I.5. The College/Academic Unit requires its students to conduct research, as a course requirement, (whenever applicable.)'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4032,
                  'parameter_item' => 'I.6. The institution provides opportunities for advanced studies and/or training to enhance faculty/staff research competence.'
                  'description' => 'I.6. The institution provides opportunities for advanced studies and/or training to enhance faculty/staff research competence.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4033,
                  'parameter_item' => 'I.7. Completed and on-going research studies are periodically monitored and evaluated in local and regional in-house reviews.'
                  'description' => 'I.7. Completed and on-going research studies are periodically monitored and evaluated in local and regional in-house reviews.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4034,
                  'parameter_item' => 'I.8. Research outputs are utilized as inputs in:'
                  'description' => 'I.8. Research outputs are utilized as inputs in:'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4035,
                  'parameter_item' => 'I.8.1. institution development;'
                  'description' => 'I.8.1. institution development;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4034', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4036,
                  'parameter_item' => 'I.8.2. improvement of instructional processes; and'
                  'description' => 'I.8.2. improvement of instructional processes; and'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4034', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4037,
                  'parameter_item' => 'I.8.3. the transfer of generated technology/knowledge to the community.'
                  'description' => 'I.8.3. the transfer of generated technology/knowledge to the community.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4034', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4038,
                  'parameter_item' => 'I.9. Packaged technologies and new information are disseminated to the target clientele through appropriate delivery systems.'
                  'description' => 'I.9. Packaged technologies and new information are disseminated to the target clientele through appropriate delivery systems.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4039,
                  'parameter_item' => 'I.10. The institution ensures that: '
                  'description' => 'I.10. The institution ensures that: '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4040,
                  'parameter_item' => 'I.10.1. research outputs are protected by IPR laws; and '
                  'description' => 'I.10.1. research outputs are protected by IPR laws; and '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4039', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4041,
                  'parameter_item' => 'I.10.2 faculty and students observe research ethics to avoid malpractices like plagiarism, fabrication of data,etc.'
                  'description' => 'I.102 faculty and students observe research ethics to avoid malpractices like plagiarism, fabrication of data,etc. '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4039', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4042,
                  'parameter_item' => 'I.5.1 Instructional Materials Development'
                  'description' => 'I.5.1 Instructional Materials Development'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4043,
                  'parameter_item' => 'I.5.2. paper presentation, journal publication, classroom lectures, and other similar activities;'
                  'description' => 'I.5.2. paper presentation, journal publication, classroom lectures, and other similar activities;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4044,
                  'parameter_item' => 'I.5.3. editorship/writing in academic, scientific and professional journals;'
                  'description' => 'I.5.3. editorship/writing in academic, scientific and professional journals;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4045,
                  'parameter_item' => 'I.5.4. thesis/dissertation advising; and'
                  'description' => 'I.5.4. thesis/dissertation advising; and'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4046,
                  'parameter_item' => 'I.5.5.patening of research outputs.'
                  'description' => 'I.5.5.patening of research outputs.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4047,
                  'parameter_item' => 'I.6. Research results are published preferably in refereed journals.'
                  'description' => 'I.6. Research results are published preferably in refereed journals.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '304', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
              'id' => 4048,
              'parameter_item' => 'I.7. Research results are disseminated to the target clientele'
              'description' => 'I.7. Research results are disseminated to the target clientele'
              'document_needed_list' => '',
              'tagged_documents' => '',
              'parameter_section_id' => '2', //parameters_section.php
              'accreditation_template_id' => '304', //accre template course area
              'template_parameter_id' => '4', // template_parameter.php
              'parent_parameter_item_id' => '', //parent 0 child 1
              'status' => 'a',
              'created_at' => date('Y-m-d H:i:s')
              ],
              [
              'id' => 4049,
              'parameter_item' => 'I.8. The College/Academic Unit generates income form patents, licenses,copyrights, and other research outputs'
              'description' => 'I.8. The College/Academic Unit generates income form patents, licenses,copyrights, and other research outputs'
              'document_needed_list' => '',
              'tagged_documents' => '',
              'parameter_section_id' => '2', //parameters_section.php
              'accreditation_template_id' => '304', //accre template course area
              'template_parameter_id' => '4', // template_parameter.php
              'parent_parameter_item_id' => '', //parent 0 child 1
              'status' => 'a',
              'created_at' => date('Y-m-d H:i:s')
              ],
              [
              'id' => 4050,
              'parameter_item' => 'O.1. Research outputs are published in referred journals'
              'description' => 'O.1. Research outputs are published in referred journals'
              'document_needed_list' => '',
              'tagged_documents' => '',
              'parameter_section_id' => '3', //parameters_section.php
              'accreditation_template_id' => '304', //accre template course area
              'template_parameter_id' => '4', // template_parameter.php
              'parent_parameter_item_id' => '', //parent 0 child 1
              'status' => 'a',
              'created_at' => date('Y-m-d H:i:s')
              ],
              [
              'id' => 4051,
              'parameter_item' => 'O.2. Research outputs are utilized.'
              'description' => 'O.2. Research outputs are utilized.'
              'document_needed_list' => '',
              'tagged_documents' => '',
              'parameter_section_id' => '3', //parameters_section.php
              'accreditation_template_id' => '304', //accre template course area
              'template_parameter_id' => '4', // template_parameter.php
              'parent_parameter_item_id' => '', //parent 0 child 1
              'status' => 'a',
              'created_at' => date('Y-m-d H:i:s')
              ],
              [
                'id' => 4052,
                'parameter_item' => 'O.3. Patented and copyrighted research outputs are commercialized.'
                'description' => 'O.3. Patented and copyrighted research outputs are commercialized.'
                'document_needed_list' => '',
                'tagged_documents' => '',
                'parameter_section_id' => '3', //parameters_section.php
                'accreditation_template_id' => '304', //accre template course area
                'template_parameter_id' => '4', // template_parameter.php
                'parent_parameter_item_id' => '', //parent 0 child 1
                'status' => 'a',
                'created_at' => date('Y-m-d H:i:s')
                ],

          ];
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $builder->insertBatch($data);
        }

        public function down()
        {
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $db->simpleQuery('DELETE FROM '.$this->table.' WHERE id >= 39 AND id <= 47');
        }
}
