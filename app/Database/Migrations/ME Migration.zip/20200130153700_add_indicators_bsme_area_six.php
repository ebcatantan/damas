<?php namespace App\Database\Migrations;

class AddIndicatorsBsmeAreaOne extends \CodeIgniter\Database\Migration {

        private $table = 'parameter_items';
        public function up()
        {
          $data = [
              [
                  'id' => 4060,
                  'parameter_item' => 'S.1. The extension agenda is in consonance of local, regional and national development thrusts and priorities.',
                  'description' => 'S.1. The extension agenda is in consonance of local, regional and national development thrusts and priorities.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4061,
                  'parameter_item' => 'S.2. The College/Academic Unit of Mechanical Engineering has a benchmark survey of the problems, needs priorities and resources of the commmunity ',
                  'description' => 'S.2. The College/Academic Unit of Mechanical Engineering has a benchmark survey of the problems, needs priorities and resources of the commmunity.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4062,
                  'parameter_item' => 'S.3. The extension program reflects the VGMO. ',
                  'description' => 'S.3. The extension program reflects the VGMO.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4063,
                  'parameter_item' => 'S.4. There is a pool of consultants/experts from various disciplines to serve in extension projects and activities.',
                  'description' => 'S.4. There is a pool of consultants/experts from various disciplines to serve in extension projects and activities.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4064,
                  'parameter_item' => 'S.5. The institution has an approved and copyrighted Extension Manual',
                  'description' => 'S.5. The institution has an approved and copyrighted Extension Manual',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4065,
                  'parameter_item' => 'I.1. The extension projects and activates implemented are based on the results of the bencmark survey.',
                  'description' => 'I.1. The extension projects and activates implemented are based on the results of the bencmark survey.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4066,
                  'parameter_item' => 'I.2. The extension projects and activities complement the curriculum of the Mechanical Engineering program under review',
                  'description' => 'I.2. The extension projects and activities complement the curriculum of the Mechanical Engineering program under review',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4067,
                  'parameter_item' => 'I.3. A mutual exchange of resources and services between the College/Academic Unit and the community is evident.',
                  'description' => 'I.3. A mutual exchange of resources and services between the College/Academic Unit and the community is evident.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4068,
                  'parameter_item' => 'I.4. Linkages with local, national, foreign, and non-governmental agencies are institutionalized.',
                  'description' => 'I.4. Linkages with local, national, foreign, and non-governmental agencies are institutionalized.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4069,
                  'parameter_item' => 'O.1. Priority and relevant extension projects and activities are conducted.',
                  'description' => 'O.1. Priority and relevant extension projects and activities are conducted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '1', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4070,
                  'parameter_item' => 'S.1. There is a distincy office that messages the Extension program.',
                  'description' => 'S.1. Thre is a distincy office that messages the Extension program.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4071,
                  'parameter_item' => 'S.2. Instruments for monitoring and evaluation are available.',
                  'description' => 'S.2.Instruments for monitoring and evaluation are available.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4072,
                  'parameter_item' => 'I.1. The administration, faculty, students and other stakeholders of the College/Academics Unit of Mechanical Engineering participate in the planning and organization of Extensions Program.',
                  'description' => 'I.1. The administration, faculty, students and other stakeholders of the College/Academics Unit of Mechanical Engineering participate in the planning and organization of Extensions Program.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4073,
                  'parameter_item' => 'I.2. The administration, faculty, students are involved in the implemention and disseminatiom of extension programs.',
                  'description' => 'I.2. The administration, faculty, students are involved in the implemention and disseminatiom of extension programs.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4074,
                  'parameter_item' => 'I.3. The extension projects and activities serve varied clientele.',
                  'description' => 'I.3. The extension projects and activities serve varied clientele.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4075,
                  'parameter_item' => 'I.4. The conduct of extension projects and activities is sustainable.',
                  'description' => 'I.4. The conduct of extension projects and activities is sustainable.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4076,
                  'parameter_item' => 'I.5. Technology/new knowledge are disseminated to the clientele through appropriate extension delivery systems.',
                  'description' => 'I.5. Technology/new knowledge are disseminated to the clientele through appropriate extension delivery systems.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4077,
                  'parameter_item' => 'I.6. The extension activities are documented in the form of: ',
                  'description' => 'I.6. The extension activities are documented in the form of: ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4078,
                  'parameter_item' => 'I.6.1. pamphlets; ',
                  'description' => 'I.6..1. pamphlets;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4077', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4079,
                  'parameter_item' => 'I.6.2. fiyers; ',
                  'description' => 'I.6..2. fiyers;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4077', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4080,
                  'parameter_item' => 'I.6.3. bulletins; ',
                  'description' => 'I.6.3. bulletins;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4077', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4081,
                  'parameter_item' => 'I.6.4. newsletters;and',
                  'description' => 'I.6.4. newsletters;and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4077', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4082,
                  'parameter_item' => 'I.6.5. electronic resources.',
                  'description' => 'I.6.5. electronic resources.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '4077', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4083,
                  'parameter_item' => 'I.7. Periodic monitoring and evaluation of extensions project and activities are conducted.',
                  'description' => 'I.7. Periodic monitoring and evaluation of extensions project and activities are conducted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4084,
                  'parameter_item' => 'I.8. Results of monitoring and evaluation are disseminated and discussed with concerned stakeholders.',
                  'description' => 'I.8. Results of monitoring and evaluation are disseminated and discussed with concerned stakeholders.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4085,
                  'parameter_item' => 'I.9. Re-planning of activities based on feedback is conducted.',
                  'description' => 'I.9. Re-planning of activities based on feedback is conducted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4086,
                  'parameter_item' => 'I.10. Accomplishment and terminal reports are filed and submitted on time.',
                  'description' => 'I.10. Accomplishment and terminal reports are filed and submitted on time.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4087,
                  'parameter_item' => 'O.1. The extension Program is well-planned, implemented, monitored, evaluated and disseminated.',
                  'description' => 'O.1. The extension Program is well-planned, implemented, monitored, evaluated and disseminated.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4088,
                  'parameter_item' => 'O.2. The Extension Program has contributed to the improvement on the quality of life of the target clientele/beneficiaries.',
                  'description' => 'O.2. The Extension Program has contributed to the improvement on the quality of life of the target clientele/beneficiaries.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '2', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4089,
                  'parameter_item' => 'S.1. There is an approved and adequate budget for extension.',
                  'description' => 'S.1. There is an approved and adequate budget for extension.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4090,
                  'parameter_item' => 'S.2. There is a provision of: ',
                  'description' => 'S.2. There is a provision of: ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4091,
                  'parameter_item' => 'S.2.1. facilities and equipment such as internet and other ICT resources;',
                  'description' => 'S.2.1. facilities and equipment such as internet and other ICT resources;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4090', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4092,
                  'parameter_item' => 'S.2.2. extension staff;',
                  'description' => 'S.2.2. extension staff;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4090', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4093,
                  'parameter_item' => 'S.2.3. supplies and materials; and',
                  'description' => 'S.2.3. supplies and materials; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4090', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4094,
                  'parameter_item' => 'S.2.3. workplace.',
                  'description' => 'S.2.3. workplace.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4090', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4095,
                  'parameter_item' => 'I.1. The budget for the extension program is utilized as planned.',
                  'description' => 'I.1. The budget for the extension program is utilized as planned.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4096,
                  'parameter_item' => 'I.2. Honoraria and other incentives(deloading, credit unit equivalent,etc.) to faculty involved in extension work are granted.',
                  'description' => 'I.2. Honoraria and other incentives(deloading, credit unit equivalent,etc.) to faculty involved in extension work are granted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4097,
                  'parameter_item' => 'I.3. The College/Academic Unit of Mechanical Engineering sources out the folliwng from other agencies:',
                  'description' => 'I.3. The College/Academic Unit of Mechanical Engineering sources out the folliwng from other agencies:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4098,
                  'parameter_item' => 'I.3.1 additonal funding; and',
                  'description' => 'I.3.1 additonal funding; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4097', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4099,
                  'parameter_item' => 'I.3.2. technical assistance and service inputs.',
                  'description' => 'I.3.2. technical assistance and service inputs.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '4097', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4100,
                  'parameter_item' => 'O.1. The Extension Program is adequately funded. ',
                  'description' => 'O.1. The Extension Program is adequately funded. ',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '3', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4101,
                  'parameter_item' => 'S.1. There is strategy for involving the community, government and private agencies in the Extension Program. '
                  'description' => 'S.1. There is strategy for involving the community, government and private agencies in the Extension Program. '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4102
                  'parameter_item' => 'I.1. The College/Academic Unit is commited to the service and development of the community, and '
                  'description' => 'I.1. The College/Academic Unit is commited to the service and development of the community, and '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4103,
                  'parameter_item' => 'I.1.1. initiates and maintains community development projects; '
                  'description' => 'I.1.1. initiates and maintains community development projects; '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4102', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4104,
                  'parameter_item' => 'I.1.2. involves the students, faculty, staff administrators int projects; and'
                  'description' => 'I.1.2. involves the students, faculty, staff administrators int projects; and'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4102', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4105,
                  'parameter_item' => 'I.1.3. coordinates its community programs and service with the target clientele.'
                  'description' => 'I.1.3. coordinates its community programs and service with the target clientele.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4102', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4106,
                  'parameter_item' => 'I.2. There is community participation and involment in extension activies in the following: '
                  'description' => 'I.2. There is community participation and involment in extension activies in the following: '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4107,
                  'parameter_item' => 'I.2.1. planning; '
                  'description' => 'I.2.1. planning; '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4106', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4108,
                  'parameter_item' => 'I.2.2. implementation and dissemination; '
                  'description' => 'I.2.2. implementation and dissemination; '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4106', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4109,
                  'parameter_item' => 'I.2.3. monitoring and evaluation; '
                  'description' => 'I.2.3. monitoring and evaluation; '
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4106', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4110,
                  'parameter_item' => 'I.2.4. out-sourcing of funds, materials and other service inputs; and'
                  'description' => 'I.2.4. out-sourcing of funds, materials and other service inputs; and'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4106', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4111,
                  'parameter_item' => 'I.2.5. utilization of technology, knowledge learned, skills acquired from the extension projects and activities.'
                  'description' => 'I.2.5. utilization of technology, knowledge learned, skills acquired from the extension projects and activities.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '4106', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 4112,
                  'parameter_item' => 'O.1. There is wholesine coordination between the Extension Program implementers and the target clientele/beneficiaries.'
                  'description' => 'O.1. There is wholesine coordination between the Extension Program implementers and the target clientele/beneficiaries.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '305', //accre template course area
                  'template_parameter_id' => '4', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],

          ];
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $builder->insertBatch($data);
        }

        public function down()
        {
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $db->simpleQuery('DELETE FROM '.$this->table.' WHERE id >= 39 AND id <= 47');
        }
}
