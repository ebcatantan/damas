<?php namespace App\Database\Migrations;

class AddIndicatorsBsmeAreaEight extends \CodeIgniter\Database\Migration {

        private $table = 'parameter_items';
        public function up()
        {
          $data = [
              [
                  'id' => 2098,
                  'parameter_item' => 'S.1. There is a Site Development Plan, and program of implementation.',
                  'description' => 'S.1. There is a Site Development Plan, and program of implementation.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2099,
                  'parameter_item' => 'S.2. The Campus has accessible good roads and pathways.',
                  'description' => 'S.2. The Campus has accessible good roads and pathways.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2100,
                  'parameter_item' => 'S.3. The campus is in a well-planned, clean and properly landscaped environment.',
                  'description' => 'S.3. The campus is in a well-planned, clean and properly landscaped environment.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2101,
                  'parameter_item' => 'S.4. There is a system to ensure that all of the following are provided:',
                  'description' => 'S.4. There is a system to ensure that all of the following are provided:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2102,
                  'parameter_item' => 'S.4.1. treffic safety in and outside the campus;',
                  'description' => 'S.4.1. treffic safety in and outside the campus;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2103,
                  'parameter_item' => 'S.4.2. waste management program;',
                  'description' => 'S.4.2. waste management program;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2104,
                  'parameter_item' => 'S.4.3. proper utilization, repair and upkeep of school facilities and equipment; and',
                  'description' => 'S.4.3. proper utilization, repair and upkeep of school facilities and equipment; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2105,
                  'parameter_item' => 'S.4.4. cleanliness and orderliness of the school campus.',
                  'description' => 'S.4.4. cleanliness and orderliness of the school campus.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2106,
                  'parameter_item' => 'I.1. The site infrastracture development plan is implemeneted as planned.',
                  'description' => 'I.1. The site infrastracture development plan is implemeneted as planned.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2107,
                  'parameter_item' => 'I.2. The site plan is strategically displayed inside the campus indicating the location of the different buildings, driveways, parking areas, etc.',
                  'description' => 'I.2. The site plan is strategically displayed inside the campus indicating the location of the different buildings, driveways, parking areas, etc.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2108,
                  'parameter_item' => 'I.3. The infrastracture development plan is implemeneted in accordance with approved zoning ordinances.',
                  'description' => 'I.3. The infrastracture development plan is implemeneted in accordance with approved zoning ordinances.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2109,
                  'parameter_item' => 'I.4. Covered walks are provided to protect the academic community from inclement weather.',
                  'description' => 'I.4. Covered walks are provided to protect the academic community from inclement weather.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2110,
                  'parameter_item' => 'I.5. The institution implements a Waste Management Program',
                  'description' => 'I.5. The institution implements a Waste Management Program',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2111,
                  'parameter_item' => 'I.6. The Maintenance Unit or its equivalent periodically inspects school facilities and equipment to ensure their proper utilization and upkeep.',
                  'description' => 'I.6. The Maintenance Unit or its equivalent periodically inspects school facilities and equipment to ensure their proper utilization and upkeep.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2112,
                  'parameter_item' => 'O.1. The campus environment is conductive to all educational activities.',
                  'description' => 'O.1. The campus environment is conductive to all educational activities.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2113,
                  'parameter_item' => 'O.2. The site can accomodate its present school population and future expansion.',
                  'description' => 'O.2. The site can accomodate its present school population and future expansion.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2114,
                  'parameter_item' => 'O.3. The campus is safe and well-maintained.',
                  'description' => 'O.3. The campus is safe and well-maintained.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2115,
                  'parameter_item' => 'O.4. The campus is well-planned, clean and properly landscaped.',
                  'description' => 'O.4. The campus is well-planned, clean and properly landscaped.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '35', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2116,
                  'parameter_item' => 'S.1. The bubildings meet all requirements of the Building Code: A Certificate of Occupancy for each building is conspicuously displayed.',
                  'description' => 'S.1. The bubildings meet all requirements of the Building Code: A Certificate of Occupancy for each building is conspicuously displayed.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2117,
                  'parameter_item' => 'S.2. The buildings are constructed according to their perspective users.',
                  'description' => 'S.2. The buildings are constructed according to their perspective users.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2118,
                  'parameter_item' => 'S.3. The buildings are well-planned and appropriately located to provide other fucntion with minimum interference to school activities.',
                  'description' => 'S.3. The buildings are well-planned and appropriately located to provide other fucntion with minimum interference to school activities.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2119,
                  'parameter_item' => 'S.4. Entry and exit points permit the use of the buildings for public and other functions with minimum interference to school activities.',
                  'description' => 'S.4. Entry and exit points permit the use of the buildings for public and other functions with minimum interference to school activities.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2120,
                  'parameter_item' => 'S.5. Emergency exits are provided and properly marked.',
                  'description' => 'S.5. Emergency exits are provided and properly marked.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2121,
                  'parameter_item' => 'S.6. The buildings are equipped with emergency/fire escapes which are readily accessible',
                  'description' => 'S.6. The buildings are equipped with emergency/fire escapes which are readily accessible',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2122,
                  'parameter_item' => 'S.7. The corridors, doorways, and alleys are well-constructed for better mobility.',
                  'description' => 'S.7. The corridors, doorways, and alleys are well-constructed for better mobility.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2123,
                  'parameter_item' => 'S.8. The buildings are well ventilated and lighted.',
                  'description' => 'S.8. The buildings are well ventilated and lighted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2124,
                  'parameter_item' => 'S.9. The buildings have facilities for person with disability (PWDs) as provided by law.',
                  'description' => 'S.9. The buildings have facilities for person with disability (PWDs) as provided by law.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2125,
                  'parameter_item' => 'S.10. There is a central signal and fire alarm system.',
                  'description' => 'S.10. There is a central signal and fire alarm system.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2126,
                  'parameter_item' => 'S.11. There are readily accessible and functional fire extinguisher and other fire-fighting equipment',
                  'description' => 'S.11. There are readily accessible and functional fire extinguisher and other fire-fighting equipment',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2127,
                  'parameter_item' => 'S.12. Bulletin boards, display boards, waste disposal containers and other amenities are startegically located inside the buildings.',
                  'description' => 'S.12. Bulletin boards, display boards, waste disposal containers and other amenities are startegically located inside the buildings.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2128,
                  'parameter_item' => 'S.12. Bulletin boards, display boards, waste disposal containers and other amenities are startegically located inside the buildings.',
                  'description' => 'S.12. Bulletin boards, display boards, waste disposal containers and other amenities are startegically located inside the buildings.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2129,
                  'parameter_item' => 'S.13. There are faculty rooms and offices.',
                  'description' => 'S.13. There are faculty rooms and offices.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2130,
                  'parameter_item' => 'S.14. The buildings are insured',
                  'description' => 'S.14. The buildings are insured',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2131,
                  'parameter_item' => 'I.1. The buildings are clean, well-maintained and free form vandalistic acts.',
                  'description' => 'I.1. The buildings are clean, well-maintained and free form vandalistic acts.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2132,
                  'parameter_item' => 'I.2. Toilets are clean and well-maintained.',
                  'description' => 'I.2. Toilets are clean and well-maintained.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2133,
                  'parameter_item' => 'I.3. Electrical lines are safety installed and periodically checked.',
                  'description' => 'I.3. Electrical lines are safety installed and periodically checked.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2134,
                  'parameter_item' => 'I.4. Water facilities are functional and well-distributed in all buildings.',
                  'description' => 'I.4. Water facilities are functional and well-distributed in all buildings.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2135,
                  'parameter_item' => 'I.5. There is a periodic potability testing of drinking water.',
                  'description' => 'I.5. There is a periodic potability testing of drinking water.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2136,
                  'parameter_item' => 'I.6. Floor plans indicating fire exits and location of fire-fighting equipment, stand pipes, and other water sources are conspicuously displayed in each building.',
                  'description' => 'I.6. Floor plans indicating fire exits and location of fire-fighting equipment, stand pipes, and other water sources are conspicuously displayed in each building.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2137,
                  'parameter_item' => 'I.7. All school facilities are periodically subjected to pest control and inspection.',
                  'description' => 'I.7. All school facilities are periodically subjected to pest control and inspection.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2138,
                  'parameter_item' => 'I.8. Smoking is strictly prohibited inside the campus.',
                  'description' => 'I.8. Smoking is strictly prohibited inside the campus.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2139,
                  'parameter_item' => 'I.9. Periodic drill on disaster and risk reduction (earthquake, flood, fire, etc.) is conducted.',
                  'description' => 'I.9. Periodic drill on disaster and risk reduction (earthquake, flood, fire, etc.) is conducted.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2140,
                  'parameter_item' => 'O.1. The buildings and other facilities are safe, well-maintained and functional.',
                  'description' => 'O.1. The buildings and other facilities are safe, well-maintained and functional.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '36', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2141,
                  'parameter_item' => 'S.1. Classroom size(1.5 sq.m per student) meets standard specifications for instruction',
                  'description' => 'S.1. Classroom size(1.5 sq.m per student) meets standard specifications for instruction',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2142,
                  'parameter_item' => 'S.2. The classrooms are well-lighted, ventilated and acoustically consditioned.',
                  'description' => 'S.2. The classrooms are well-lighted, ventilated and acoustically consditioned.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2143,
                  'parameter_item' => 'S.3. The classrooms are adequate and are provided with enough chairs, furniture and equipment.',
                  'description' => 'S.3. The classrooms are adequate and are provided with enough chairs, furniture and equipment.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2144,
                  'parameter_item' => 'S.4. There are sufficient supplies (chalkboards/whiteboards, and Instructional materials) in each classroom.',
                  'description' => 'S.4. There are sufficient supplies (chalkboards/whiteboards, and Instructional materials) in each classroom.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2145,
                  'parameter_item' => 'I.1. The classrooms are clearly marked and arragned relative to their fucntions.',
                  'description' => 'I.1. The classrooms are clearly marked and arragned relative to their fucntions.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2146,
                  'parameter_item' => 'I.2. The classrooms are well-maintained and free from interference.',
                  'description' => 'I.2. The classrooms are well-maintained and free from interference.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2147,
                  'parameter_item' => 'I.3. Students cooperate in maintaining the cleanliness and orderliness of the classrooms.',
                  'description' => 'I.3. Students cooperate in maintaining the cleanliness and orderliness of the classrooms.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2148,
                  'parameter_item' => 'O.1. Classrooms are adequate and conducive to learning.',
                  'description' => 'O.1. Classrooms are adequate and conducive to learning.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '37', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2149,
                  'parameter_item' => 'S.1. The administrative offices are accessible to stakeholders.',
                  'description' => 'S.1. The administrative offices are accessible to stakeholders.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2150,
                  'parameter_item' => 'S.2. All offices are accessible and conveniently located in accordance to their function.',
                  'description' => 'S.2. All offices are accessible and conveniently located in accordance to their function.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2151,
                  'parameter_item' => 'S.3. There are offices and workspaces for all officials, faculty and administrative staff.',
                  'description' => 'S.3. There are offices and workspaces for all officials, faculty and administrative staff.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2152,
                  'parameter_item' => 'S.4. Administration and faculty offices and sstaff rooms are clean, well-lighted and ventilated',
                  'description' => 'S.4. Administration and faculty offices and sstaff rooms are clean, well-lighted and ventilated',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2153,
                  'parameter_item' => 'S.5. Function rooms and lounge are available and accessible.',
                  'description' => 'S.5. Function rooms and lounge are available and accessible.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2154,
                  'parameter_item' => 'S.6. Storerooms are strategically located.',
                  'description' => 'S.6. Storerooms are strategically located.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2155,
                  'parameter_item' => 'S.7. There is internal and external communication system.',
                  'description' => 'S.7. There is internal and external communication system.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2156,
                  'parameter_item' => 'S.8. There are clean toilets for administrators, faculty, staff, and students.',
                  'description' => 'S.8. There are clean toilets for administrators, faculty, staff, and students.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2157,
                  'parameter_item' => 'I.1. All offices are furnished with the necessary equipment, furniture, suppplies and materials',
                  'description' => 'I.1. All offices are furnished with the necessary equipment, furniture, suppplies and materials',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2158,
                  'parameter_item' => 'I.2. All offices are well-maintained',
                  'description' => 'I.2. All offices are well-maintained',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2159,
                  'parameter_item' => 'O.1. The offices are staff rooms are adequate and conducive to working environment.',
                  'description' => 'O.1. The offices are staff rooms are adequate and conducive to working environment.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '38', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2160,
                  'parameter_item' => 'S.1. The administrative offices are accessible to stakeholders.',
                  'description' => 'S.1. The administrative offices are accessible to stakeholders.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2161,
                  'parameter_item' => 'S.2. Facilities for athletic sports, cultural activities, military training, etc. are accessible.',
                  'description' => 'S.2. Facilities for athletic sports, cultural activities, military training, etc. are accessible.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2162,
                  'parameter_item' => 'S.3. The seating capacity conforms to standards.',
                  'description' => 'S.3. The seating capacity conforms to standards.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2163,
                  'parameter_item' => 'S.4. There are adequate and well-marked entry and exit points.',
                  'description' => 'S.4. There are adequate and well-marked entry and exit points.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2164,
                  'parameter_item' => 'S.5. There are storage facilities for athletic sports and other curricular training Equipment',
                  'description' => 'S.5. There are storage facilities for athletic sports and other curricular training Equipment',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2165,
                  'parameter_item' => 'I.1. Indoor facilities are constructed with:',
                  'description' => 'I.1. Indoor facilities are constructed with:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2166,
                  'parameter_item' => 'I.1.1. appropriate flooring;',
                  'description' => 'I.1.1. appropriate flooring;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2167,
                  'parameter_item' => 'I.1.2. proper lighting and ventilation;',
                  'description' => 'I.1.2. proper lighting and ventilation;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2167,
                  'parameter_item' => 'I.1.3. safety measures;',
                  'description' => 'I.1.3. safety measures;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2168,
                  'parameter_item' => 'I.1.4. toilets;',
                  'description' => 'I.1.4. toilets;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2169,
                  'parameter_item' => 'I.1.5. functional drinking facilities; and',
                  'description' => 'I.1.5. functional drinking facilities; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2170,
                  'parameter_item' => 'I.1.6. enough chairs.',
                  'description' => 'I.1.6. enough chairs.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2171,
                  'parameter_item' => 'I.2. The constructed outdoor facilities are:',
                  'description' => 'I.2. The constructed outdoor facilities are:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2172,
                  'parameter_item' => 'I.2.1. free from hazards;',
                  'description' => 'I.2.1. free from hazards;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2173,
                  'parameter_item' => 'I.2.2. suitably surfaced floor;',
                  'description' => 'I.2.2. suitably surfaced floor;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2174,
                  'parameter_item' => 'I.2.3. appropriately laid out for a variety of activities;',
                  'description' => 'I.2.3. appropriately laid out for a variety of activities;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2175,
                  'parameter_item' => 'I.2.4. properly maintained and secured; and',
                  'description' => 'I.2.4. properly maintained and secured; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2175,
                  'parameter_item' => 'I.2.5. installed with drainege system.',
                  'description' => 'I.2.5. installed with drainege system.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2175,
                  'parameter_item' => 'I.2.5. installed with drainege system.',
                  'description' => 'I.2.5. installed with drainege system.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2176,
                  'parameter_item' => 'I.3. Assembly, athletic sports and cultural facilities are sufficient and varied to meet the requirements of the institution.',
                  'description' => 'I.3. Assembly, athletic sports and cultural facilities are sufficient and varied to meet the requirements of the institution.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2177,
                  'parameter_item' => 'I.4. Audio-visual room and facilities with appropriate equipment are utilized in support of the teaching-learning such as but not limited to video/overhead/slide projector, sound sytem, LCD projectors and screens.',
                  'description' => 'I.4. Audio-visual room and facilities with appropriate equipment are utilized in support of the teaching-learning such as but not limited to video/overhead/slide projector, sound sytem, LCD projectors and screens.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2178,
                  'parameter_item' => 'O.1. Indoor and outdoor facilities are well-equipped and properly maintained.',
                  'description' => 'O.1. Indoor and outdoor facilities are well-equipped and properly maintained.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '39', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2179,
                  'parameter_item' => 'S.1. The Medical and Dental Clinic has basic facilities such as; reception area, records section, examination/ treatment room and toilets.',
                  'description' => 'S.1./ The Medical and Dental Clinic has basic facilities such as; reception area, records section, examination/ treatment room and toilets.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2180,
                  'parameter_item' => 'S.2. The institution has functional medical and dental section/area.',
                  'description' => 'S.2. The institution has functional medical and dental section/area.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2181,
                  'parameter_item' => 'S.3. Potable water is available and sufficient.',
                  'description' => 'S.3. Potable water is available and sufficient.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2182,
                  'parameter_item' => 'S.4. Medical and dental equipment are provided.',
                  'description' => 'S.4. Medical and dental equipment are provided.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2183,
                  'parameter_item' => 'S.5. There are enough medical and dental supplies and materials.',
                  'description' => 'S.5. There are enough medical and dental supplies and materials.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2184,
                  'parameter_item' => 'S.5. There are enough medical and dental supplies and materials.',
                  'description' => 'S.5. There are enough medical and dental supplies and materials.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2185,
                  'parameter_item' => 'S.6. Storage facilities (refrigerator, steak cabinets, etc.) are available.',
                  'description' => 'S.6. Storage facilities (refrigerator, steak cabinets, etc.) are available.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2186,
                  'parameter_item' => 'S.7. Medical and dental supplies and materials are properly labeled.',
                  'description' => 'S.7. Medical and dental supplies and materials are properly labeled.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2187,
                  'parameter_item' => 'S.8. The following basic medical equipment and medicines are all available.',
                  'description' => 'S.8. The following basic medical equipment and medicines are all available.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2188,
                  'parameter_item' => 'S.8.1. emergency medicines;',
                  'description' => 'S.8.1. emergency medicines;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2189,
                  'parameter_item' => 'S.8.2. ambo bag;',
                  'description' => 'S.8.2. ambo bag;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2190,
                  'parameter_item' => 'S.8.3. oxygen tank;',
                  'description' => 'S.8.3. oxygen tank;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2191,
                  'parameter_item' => 'S.8.4. intravenous fluid',
                  'description' => 'S.8.4. intravenous fluid',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2192,
                  'parameter_item' => 'S.8.5. sphygmomanometer (at least 2 sets);',
                  'description' => 'S.8.5. sphygmomanometer (at least 2 sets);',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2193,
                  'parameter_item' => 'S.8.6. thermometer (at least 10 pcs.);',
                  'description' => 'S.8.6. thermometer (at least 10 pcs.);',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2194,
                  'parameter_item' => 'S.8.7. diagnostic sets;',
                  'description' => 'S.8.7. diagnostic sets;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2195,
                  'parameter_item' => 'S.8.8. stethoscope (at least 2 units);',
                  'description' => 'S.8.8. stethoscope (at least 2 units);',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2196,
                  'parameter_item' => 'S.8.9. treatment cart; and',
                  'description' => 'S.8.9. treatment cart; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2197,
                  'parameter_item' => 'S.8.10. nebulizer.',
                  'description' => 'S.8.10. nebulizer.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2198,
                  'parameter_item' => 'S.9. The following basic dental equipment and apparatuses are available:',
                  'description' => 'S.9. The following basic dental equipment and apparatuses are available:',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2199,
                  'parameter_item' => 'S.9.1. dental chair;',
                  'description' => 'S.9.1. dental chair;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2200,
                  'parameter_item' => 'S.9.2. autoclave (sterilizers);',
                  'description' => 'S.9.2. autoclave (sterilizers);',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2201,
                  'parameter_item' => 'S.9.3. medical supplies;',
                  'description' => 'S.9.3. medical supplies;',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2202,
                  'parameter_item' => 'S.9.4. filling instruments; and',
                  'description' => 'S.9.4. filling instruments; and',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2203,
                  'parameter_item' => 'S.9.5. basic instuments (forceps, mouth mirror, cotton fliers,
                  explorer, etc).',
                  'description' => 'S.9.5. basic instuments (forceps, mouth mirror, cotton fliers,
                  explorer, etc).',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2204,
                  'parameter_item' => 'S.10. The Medical/Dental Clinic has ample apace, adequate lighting and a ventilation.',
                  'description' => 'S.10. The Medical/Dental Clinic has ample apace, adequate lighting and a ventilation.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2205,
                  'parameter_item' => 'I.1. The medical and Dental clinics are managed by qualified medical and dental a officers.',
                  'description' => 'I.1. The medical and Dental clinics are managed by qualified medical and dental a officers.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2206,
                  'parameter_item' => 'I.2. Distinct rooms and storage areas are properly labeled.',
                  'description' => 'I.2. Distinct rooms and storage areas are properly labeled.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2207,
                  'parameter_item' => 'I.3. Medical and dental services are regularly monitored and evaluated',
                  'description' => 'I.3. Medical and dental services are regularly monitored and evaluated',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2208,
                  'parameter_item' => 'O.1. The medical. Dental clinic and services are functional.',
                  'description' => 'O.1. The medical. Dental clinic and services are functional.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '40', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2209,
                  'parameter_item' => 'S.1. The institution has a Student Center with supplies and materials.',
                  'description' => 'S.1. The institution has a Student Center with supplies and materials.',
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2210,
                  'parameter_item' => 'S.2. Policies and guidance on the proper utilization of Student Center are in a place.',
                  'description' => 'S.2. Policies and guidance on the proper utilization of Student Center are in a place.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2211,
                  'parameter_item' => 'S.3. The Student Center is well-lighted and ventilated.',
                  'description' => 'S.3. The Student Center is well-lighted and ventilated.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2212,
                  'parameter_item' => 'S.4. A conference room is available for students’ use.',
                  'description' => 'S.4. A conference room is available for students’ use.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2213,
                  'parameter_item' => 'S.5. There are facilities and equipment for table games, music appreciation, and a TV or video viewing.',
                  'description' => 'S.5. There are facilities and equipment for table games, music appreciation, and a TV or video viewing.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2214,
                  'parameter_item' => 'S.6. Clean and sanitary toilets, for men separate from those of women are a available.',
                  'description' => 'S.6. Clean and sanitary toilets, for men separate from those of women are a available.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2215,
                  'parameter_item' => 'S.7. Toilet fixtures for students with special needs and PWD’s are provided.',
                  'description' => 'S.7. Toilet fixtures for students with special needs and PWD’s are provided.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2216,
                  'parameter_item' => 'S.8. There are officers for student leaders, the editorial staff of the students a publication and the officers of the student organization.',
                  'description' => 'S.8. There are officers for student leaders, the editorial staff of the students a publication and the officers of the student organization.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2217,
                  'parameter_item' => 'I.1. Student activities at the Student Center are regularly conducted and a monitored',
                  'description' => 'I.1. Student activities at the Student Center are regularly conducted and a monitored'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2218,
                  'parameter_item' => 'I.2. The Student Center is properly maintained.',
                  'description' => 'I.2. The Student Center is properly maintained.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2219,
                  'parameter_item' => 'O.1. The Student Center is fully equipped and functional.',
                  'description' => 'O.1. The Student Center is fully equipped and functional.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '41', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2220,
                  'parameter_item' => 'S.1. The canteen/cafeteria is well-lighted, ventilated, screened and provided with a potable water supply.',
                  'description' => 'S.1. The canteen/cafeteria is well-lighted, ventilated, screened and provided with a potable water supply.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2221,
                  'parameter_item' => 'S.2. There are enough;',
                  'description' => 'S.2. There are enough;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2222,
                  'parameter_item' => 'S.2.1. cooking and preparatory equipment;',
                  'description' => 'S.2.1. cooking and preparatory equipment;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2223,
                  'parameter_item' => 'S.2.2 serving tools and utensils;',
                  'description' => 'S.2.2 serving tools and utensils;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2224,
                  'parameter_item' => 'S.2.3 cleaning supplies and materials; and',
                  'description' => 'S.2.3 cleaning supplies and materials; and'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2225,
                  'parameter_item' => 'S.2.4 dining tables and chairs.',
                  'description' => 'S.2.4 dining tables and chairs.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2226,
                  'parameter_item' => 'S.3. Wash area and toilets are available.',
                  'description' => 'S.3. Wash area and toilets are available.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2227,
                  'parameter_item' => 'I.1. The institution requires business and sanitary permits for the operation of a the Food Center/Cafeteria/ Canteen.',
                  'description' => 'I.1. The institution requires business and sanitary permits for the operation of a the Food Center/Cafeteria/ Canteen.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2228,
                  'parameter_item' => 'I.2. The Student Center is properly maintained.',
                  'description' => 'I.2. The Student Center is properly maintained.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2229,
                  'parameter_item' => 'I.3. The Food Center/ Cafeteria/Canteen is well-managed by qualified and a competent staff.',
                  'description' => 'I.3. The Food Center/ Cafeteria/Canteen is well-managed by qualified and a competent staff.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2230,
                  'parameter_item' => 'I.4. Cleanliness and orderliness are enforced.',
                  'description' => 'I.4. Cleanliness and orderliness are enforced.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2231,
                  'parameter_item' => 'I.5. The food services are prompt.',
                  'description' => 'I.5. The food services are prompt.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2232,
                  'parameter_item' => 'O.1. The Canteen/Cafeteria/Food Center is well-patronized.',
                  'description' => 'O.1. The Canteen/Cafeteria/Food Center is well-patronized.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2233,
                  'parameter_item' => 'O.2. The food services generate income for the institution.',
                  'description' => 'O.2. The food services generate income for the institution.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '42', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2234,
                  'parameter_item' => 'S.1. The Accreditation Center (AC) is accessible and conveniently located.',
                  'description' => 'S.1. The Accreditation Center (AC) is accessible and conveniently located.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2235,
                  'parameter_item' => 'S.2. The AC has the following equipment and fixtures:',
                  'description' => 'S.2. The AC has the following equipment and fixtures:'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2236,
                  'parameter_item' => 'S.2.1. working tables and chairs;',
                  'description' => 'S.2.1. working tables and chairs;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2237,
                  'parameter_item' => 'S.2.2 cabinets for display and filing;',
                  'description' => 'S.2.2 cabinets for display and filing;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2238,
                  'parameter_item' => 'S.2.3 good ventilation and lighting;',
                  'description' => 'S.2.3 good ventilation and lighting;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2239,
                  'parameter_item' => 'S.2.4. computer unit;',
                  'description' => 'S.2.4. computer unit;'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2240,
                  'parameter_item' => 'S.2.5. toilets; and',
                  'description' => 'S.2.5. toilets; and'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2241,
                  'parameter_item' => 'S.2.6. lounge.',
                  'description' => 'S.2.6. lounge.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '1', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2242,
                  'parameter_item' => 'I.1. The Institution/College/Academic Unit maintains the AC with the required a resources, furniture and documents.',
                  'description' => 'I.1. The Institution/College/Academic Unit maintains the AC with the required a resources, furniture and documents.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2243,
                  'parameter_item' => 'I.2. The AC is manage by a qualified and committed staff/faculty.',
                  'description' => 'I.2. The AC is manage by a qualified and committed staff/faculty.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2244,
                  'parameter_item' => 'I.3. Required documents/information and exhibits are updated, systematically a packaged and readily available.',
                  'description' => 'I.3. Required documents/information and exhibits are updated, systematically a packaged and readily available.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2245,
                  'parameter_item' => 'O.1. The AC is ewll-equipped and managed.',
                  'description' => 'O.1. The AC is ewll-equipped and managed.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '43', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2246,
                  'parameter_item' => 'S.1. There are dormitories and housing facilities for students, faculty and staff.',
                  'description' => 'S.1. There are dormitories and housing facilities for students, faculty and staff.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2247,
                  'parameter_item' => 'S.2. There is an Implementing Rules and Regulation (IRR) for in-campus housing a services.',
                  'description' => 'S.2. There is an Implementing Rules and Regulation (IRR) for in-campus housing a services.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2248,
                  'parameter_item' => 'S.3. There is a system of coordinating with LGU’s on privately owned boarding a houses.',
                  'description' => 'S.3. There is a system of coordinating with LGU’s on privately owned boarding a houses.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '1', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2249,
                  'parameter_item' => 'I.1 The housing facilities are functionally designed',
                  'description' => 'I.1 The housing facilities are functionally designed'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2250,
                  'parameter_item' => 'I.2 The housing facilities and surroundings are properly maintained and monitored',
                  'description' => 'I.2 The housing facilities and surroundings are properly maintained and monitored'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2251,
                  'parameter_item' => 'I.3 The IRR on housing services is strictly followed (e.g. dormitory fees, etc.)',
                  'description' => 'I.3 The IRR on housing services is strictly followed (e.g. dormitory fees, etc.)'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2252,
                  'parameter_item' => 'I.4 The institution coordinates with LGU’s and owners of private boarding houses',
                  'description' => 'I.4 The institution coordinates with LGU’s and owners of private boarding houses'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '2', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2253,
                  'parameter_item' => 'O.1. The housing facilities are safe, habitable and well-maintained.',
                  'description' => 'O.1. The housing facilities are safe, habitable and well-maintained.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],
              [
                  'id' => 2254,
                  'parameter_item' => 'O.2. There is wholesome coordination among the Institution, the LGU’s and the owners of private boarding houses.',
                  'description' => 'O.2. There is wholesome coordination among the Institution, the LGU’s and the owners of private boarding houses.'
                  'document_needed_list' => '',
                  'tagged_documents' => '',
                  'parameter_section_id' => '3', //parameters_section.php
                  'accreditation_template_id' => '307', //accre template course area
                  'template_parameter_id' => '44', // template_parameter.php
                  'parent_parameter_item_id' => '0', //parent 0 child 1
                  'status' => 'a',
                  'created_at' => date('Y-m-d H:i:s')
              ],

          ];
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $builder->insertBatch($data);
        }

        public function down()
        {
          $db      = \Config\Database::connect();
          $builder = $db->table($this->table);
          $db->simpleQuery('DELETE FROM '.$this->table.' WHERE id >= 39 AND id <= 47');
        }
}
